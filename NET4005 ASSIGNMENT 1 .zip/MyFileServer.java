    import java.io.*;
    import java.net.*;
    import java.util.concurrent.*;
    import java.util.concurrent.atomic.AtomicInteger;

    public class MyFileServer {
        private static final int PORT = 45678;  // Port updated to match the client
        private static ExecutorService threadPool = Executors.newFixedThreadPool(10);
        private static AtomicInteger totalRequests = new AtomicInteger(0);
        private static AtomicInteger successfulRequests = new AtomicInteger(0);

        public static void main(String[] args) throws IOException {
            ServerSocket serverSocket = new ServerSocket(PORT);
            System.out.println("Server is running on port " + PORT + "...");

            try {
                while (true) {
                    Socket clientSocket = serverSocket.accept();
                    Runnable worker = new ClientHandler(clientSocket);
                    threadPool.execute(worker);
                }
            } finally {
                serverSocket.close();
            }
        }

        private static class ClientHandler implements Runnable {
            private Socket clientSocket;

            public ClientHandler(Socket socket) {
                this.clientSocket = socket;
            }

            public void run() {
                try {
                    handleClient(clientSocket);
                } catch (IOException e) {
                    e.printStackTrace();
                } finally {
                    try {
                        clientSocket.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }

            private void handleClient(Socket socket) throws IOException {
                try (DataOutputStream out = new DataOutputStream(socket.getOutputStream());
                     BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()))) {

                    String fileName = in.readLine();  // Get the requested file name from the client
                    File file = new File(fileName);
                    int requestNumber = totalRequests.incrementAndGet();

                    System.out.println("REQ " + requestNumber + ": File " + fileName + " requested from " + socket.getInetAddress());

                    if (file.exists()) {
                        successfulRequests.incrementAndGet();
                        System.out.println("REQ " + requestNumber + ": Sending 'File found' to client...");
                        out.writeUTF("File found");  // "File found" message

                        // Send file content
                        try (FileInputStream fileIn = new FileInputStream(file)) {
                            byte[] buffer = new byte[4096];
                            int bytesRead;
                            while ((bytesRead = fileIn.read(buffer)) != -1) {
                                out.write(buffer, 0, bytesRead);  // Send file content
                            }
                        }
                        System.out.println("REQ " + requestNumber + ": File transfer complete");
                        out.writeUTF("Download complete");  // Notify client that file transfer is complete
                    } else {
                        System.out.println("REQ " + requestNumber + ": Sending 'File not found' to client...");
                        out.writeUTF("File not found");  // Send "File not found" message
                    }

                    System.out.println("REQ " + requestNumber + ": Total successful requests so far = " + successfulRequests.get());
                }
            }
        }
    }
