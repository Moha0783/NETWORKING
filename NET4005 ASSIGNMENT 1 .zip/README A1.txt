This submission is for the NET 4005: Network Applications assignment. It includes a Java-based client-server application that allows the client to request a file from the server. The server responds with whether the file is available, sends file-related statistics, and transfers the file (if found).

The server handles multiple concurrent clients using a fixed thread pool of 10 worker threads.


FILES:

MyFileServer.java:

This is the server program that listens for client requests, checks for the requested file, and sends either the file or a "file not found" message to the client. It also provides statistics about the total and successful requests.


MyFileClient.java:

This is the client program that connects to the server, requests a file, and either receives the file or is informed that the file was not found. It displays the server's response, statistics, and downloads the file if it exists.

PROTOCOL.TXT:

This file describes the communication protocol between the client and server, including the message formats and their meanings.



