import java.io.*;
import java.net.*;

public class MyFileClient {
    public static void main(String[] args) throws IOException {
        if (args.length < 3) {
            System.out.println("Usage: java MyFileClient <server_IP> <server_port> <filename>");
            return;
        }

        String serverIP = args[0];
        int serverPort = Integer.parseInt(args[1]);
        String fileName = args[2];

        // Try-with-resources to manage socket and streams efficiently
        try (Socket socket = new Socket(serverIP, serverPort);
             DataInputStream in = new DataInputStream(socket.getInputStream());
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true)) {

            // Send the file name to the server
            out.println(fileName);

            // Read server's response about the file status (found/not found)
            String response = in.readUTF();

            if (response.equals("File found")) {
                System.out.println("File " + fileName + " found at server");

                // Read the total requests (N) and successful requests (M)
                int totalRequests = in.readInt();  // N
                int successfulRequests = in.readInt();  // M

                System.out.println("Server handled " + totalRequests + " requests, " + successfulRequests + " requests were successful");
                System.out.println("Downloading file " + fileName);

                // Start downloading the file
                try (FileOutputStream fileOut = new FileOutputStream(fileName)) {
                    byte[] buffer = new byte[4096];
                    int bytesReceived;

                    // Read the file content from the server until the end of the stream
                    while ((bytesReceived = in.read(buffer)) != -1) {
                        fileOut.write(buffer, 0, bytesReceived);
                    }
                }

                // file transfer is complete
                System.out.println("Download complete");

            } else {
                System.out.println("File " + fileName + " not found at server");

                // Read the total requests (N) and successful requests (M)
                int totalRequests = in.readInt();  // N
                int successfulRequests = in.readInt();  // M

                System.out.println("Server handled " + totalRequests + " requests, " + successfulRequests + " requests were successful");
            }
        }
    }
}

