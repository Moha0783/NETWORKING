-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 10, 2024 at 09:55 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fitnesst`
--

-- --------------------------------------------------------

--
-- Table structure for table `exercises`
--

CREATE TABLE `exercises` (
  `name` varchar(255) NOT NULL,
  `type` varchar(50) NOT NULL,
  `muscle` varchar(50) NOT NULL,
  `equipment` varchar(50) NOT NULL,
  `difficulty` varchar(50) NOT NULL,
  `instructions` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `exercises`
--

INSERT INTO `exercises` (`name`, `type`, `muscle`, `equipment`, `difficulty`, `instructions`) VALUES
('Incline Twist Curls', 'strength', 'biceps', 'dumbbell', 'beginner', 'Sit on an incline bench with a dumbbell in each hand, back pressed against it, feet together. Let the dumbbells hang at your sides with a neutral grip. Begin by flexing at the elbow, keeping the upper arm static. Rotate the wrists slightly as you lift, adding a twist to engage more of the bicep. Pause at the top, then slowly return to the start.'),
('Barbell Curl Wide Grip', 'strength', 'biceps', 'barbell', 'beginner', 'Stand upright holding a barbell with a wide grip. Palms should face forward, elbows close to your torso. Curl the weights while keeping upper arms stationary. Focus on isolating the bicep muscle during the curl. Pause when fully contracted, then slowly lower the barbell. For variation, use an E-Z bar or a cable machine.'),
('Preacher Bench EZ-bar Curls', 'strength', 'biceps', 'barbell', 'intermediate', 'Set the bar on the preacher bench\'s seat. Lie with your torso against the bench at a 45-degree angle. Grab the bar with a supinated grip, arms shoulder-width apart. Curl the bar, exhale, squeeze the biceps at the top. Slowly return to start. Dumbbells can be used for variation.'),
('Vertical Hammer Curls', 'strength', 'biceps', 'dumbbell', 'intermediate', 'Stand straight with a dumbbell in each hand, arms hanging by your side. Palms facing your torso. Curl the weights, keeping your upper arm still. Only move your forearm. At the top, squeeze the biceps, then lower slowly. Alternate arms or perform seated for variations.'),
('Twist EZ-Bar Curl', 'strength', 'biceps', 'e-z_curl_bar', 'intermediate', 'Hold an EZ curl bar with a wide grip, palms facing forward. Curl the bar, keeping your upper arms stationary. At the top, twist your wrists slightly for an extra bicep squeeze. Lower the bar slowly. Use cable attachments for variations.'),
('Rotating Zottman Curl', 'strength', 'biceps', 'None', 'intermediate', 'Stand upright with a dumbbell in each hand, arms at your side. Curl the weights with a supinated grip. At the top, rotate to a pronated grip and lower slowly. Rotate back to a neutral grip at the start. Repeat for the desired reps.'),
('Curl Press Combo', 'strength', 'biceps', 'dumbbell', 'beginner', 'Stand with a dumbbell in each hand, palms facing forward. Curl the weights, keeping elbows stationary. Transition into a shoulder press by extending your arms above your head. Return to the starting position and repeat for the desired number of reps.'),
('Standard Barbell Curl', 'strength', 'biceps', 'barbell', 'intermediate', 'Stand upright, holding a barbell with a shoulder-width grip. Curl the barbell, keeping your forearms isolated and elbows stationary. Squeeze the biceps at the top, then slowly lower back down. Repeat for the desired number of reps.');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `UserID` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `Fullname` varchar(50) NOT NULL,
  `permissions` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`UserID`, `username`, `password`, `Fullname`, `permissions`) VALUES
(0, 'admin@gmail.com', 'password', '0000-00-00', 3),
(0, 'Test1@gmail.com', '123', '', 2),
(0, 'test2@gmail.com', '123', '', 2);

-- --------------------------------------------------------

--
-- Table structure for table `userworkouts`
--

CREATE TABLE `userworkouts` (
  `UserID` int(11) DEFAULT NULL,
  `ExerciseName` varchar(255) DEFAULT NULL,
  `Weight` int(11) DEFAULT NULL,
  `Reps` int(11) DEFAULT NULL,
  `DateLogged` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `workouts`
--

CREATE TABLE `workouts` (
  `name` varchar(255) NOT NULL,
  `type` varchar(50) DEFAULT NULL,
  `muscle` varchar(50) DEFAULT NULL,
  `equipment` varchar(50) DEFAULT NULL,
  `difficulty` varchar(50) DEFAULT NULL,
  `instructions` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `userworkouts`
--
ALTER TABLE `userworkouts`
  ADD KEY `ExerciseName` (`ExerciseName`);

--
-- Indexes for table `workouts`
--
ALTER TABLE `workouts`
  ADD PRIMARY KEY (`name`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `userworkouts`
--
ALTER TABLE `userworkouts`
  ADD CONSTRAINT `userworkouts_ibfk_1` FOREIGN KEY (`ExerciseName`) REFERENCES `workouts` (`name`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
