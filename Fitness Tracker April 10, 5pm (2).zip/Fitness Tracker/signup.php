<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    include('db.php');
    
    $fullname = mysqli_real_escape_string($conn, $_POST['fullname']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);

    $stmt = $conn->prepare("INSERT INTO users (username, password, permissions) VALUES (?, ?, ?)");
    $permissions = 2;
    $stmt->bind_param("ssi", $email, $password, $permissions);

    if ($stmt->execute()) {
        $_SESSION['username'] = $email;
        $_SESSION['fullname'] = $fullname;
        $_SESSION['permissions'] = $permissions;
        header("location: user.php");
        exit;
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up - Fitness Tracker</title>
    <link href="style.css" rel="stylesheet">
</head>
<body>
    <div class="container">
        <h2>Sign Up</h2>
        <form id="signupForm" class="form-style" method="post" action="signup.php">
            <input type="text" name="fullname" placeholder="Full Name" required>
            <input type="email" name="email" placeholder="Email" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit">Sign Up</button>
        </form>
        <a href="index.html" class="back-link">Back to Home</a>
    </div>
</body>
</html>



