<?php
include('db.php'); 

$stmt = $conn->prepare("SELECT name, type, muscle, equipment, difficulty FROM exercises");
$stmt->execute();
$result = $stmt->get_result();

$exercises = [];
while ($row = $result->fetch_assoc()) {
    $exercises[] = $row;
}

$stmt->close();
$conn->close();

