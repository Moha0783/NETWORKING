<?php 
session_start(); 
if(!isset($_SESSION['username'])) { 
    header('Location: login.php'); 
    exit; 
} 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="style.css" rel="stylesheet">
</head>
<body>
    <div id="user-page" class="container">
        <h1>Welcome <?php echo isset($_SESSION['fullname']) ? $_SESSION['fullname'] : ''; ?>!</h1>
        <div class="button-container">
            <button onclick="window.location.href='log_workout.php';">Start Logging</button>
            <button onclick="window.location.href='past_log.php';">Past Logs</button>
            <button onclick="window.location.href='logout.php';">Log Out</button>
        </div>
    </div>
</body>
</html>

