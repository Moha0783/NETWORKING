<?php
session_start();
$isLoggedIn = isset($_SESSION['username']); 
include('db.php');

$error = ''; 

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = mysqli_real_escape_string($conn, $_POST['username']); 
    $password = mysqli_real_escape_string($conn, $_POST['password']);

    $stmt = $conn->prepare("SELECT username, password FROM users WHERE username = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        if ($row['password'] === $password) {
            $_SESSION['username'] = $row['username'];
            header("location: user.php");
            exit;
        } else {
            $error = "Incorrect password."; 
        }
    } else {
        $error = "User not found.";
    }
    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Fitness Tracker</title>
    <link href="style.css" rel="stylesheet">
</head>
<body>
    <div class="container">
        <?php if ($isLoggedIn): ?>
            <h2>Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?>!</h2>
            <form action="logout.php" method="post">
                <button type="submit" name="logout">Logout</button>
            </form>
        <?php else: ?>
            <h2>Login</h2>
            <form id="loginForm" class="form-style" method="post" action="login.php">
                <input type="email" name="username" placeholder="Email" required>
                <input type="password" name="password" placeholder="Password" required>
                <button type="submit">Login</button>
            </form>
            <?php if (!empty($error)): ?>
                <div class="error-message"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>
        <?php endif; ?>
        <a href="index.html" class="back-link">Back</a>
    </div>
</body>
</html>
