<?php
session_start();
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit;
}

require_once 'db.php';  

$username = $_SESSION['username'];

$query = "SELECT ExerciseName, Weight, Reps, DateLogged FROM UserWorkouts WHERE Username = ? ORDER BY DateLogged DESC";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

$workoutLogs = [];
while ($row = $result->fetch_assoc()) {
    $workoutLogs[] = $row;
}

$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Past Logs</title>
    <link href="style.css" rel="stylesheet">
</head>
<body>
    <div class="container">
        <h1>Past Activity Logs</h1>
        <?php if (!empty($workoutLogs)): ?>
            <table>
                <thead>
                    <tr>
                        <th>Exercise Name</th>
                        <th>Weight</th>
                        <th>Reps</th>
                        <th>Date Logged</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($workoutLogs as $log): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($log['ExerciseName']); ?></td>
                            <td><?php echo htmlspecialchars($log['Weight']); ?></td>
                            <td><?php echo htmlspecialchars($log['Reps']); ?></td>
                            <td><?php echo htmlspecialchars($log['DateLogged']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No workout logs found.</p>
        <?php endif; ?>

        <a href="user.php" class ="btn" >Back to Home</a>
        <a href="log_workout.php" class = "btn" >Log an exercise!</a>
    </div>
</body>
</html>

