<?php session_start(); if(!isset($_SESSION['username'])) { header('Location: login.php'); exit; } ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Log Activity</title>
    <link href="style.css" rel="stylesheet">
</head>
<body>
    <div class="container">
        <h1>Log Your Activity</h1>
        <a href="user.php">Back to Home</a>
        <a href="logout.php">Logout</a>
    </div>
</body>
</html>
