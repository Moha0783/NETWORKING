<?php

ini_set('display_errors', 1);
error_reporting(E_ALL);

session_start();
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit;
}

require_once 'db.php'; 

$query = "SELECT name FROM exercises";
$result = $conn->query($query);

$exercises = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $exercises[] = $row['name'];
    }
}
// Do not close the connection here if you need it later for POST handling

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    require_once 'db.php'; // Make sure the database connection is open

    // Sanitize and validate the inputs
    $exerciseName = $conn->real_escape_string($_POST['exercise']);
    $weight = (int) $_POST['weight'];
    $reps = (int) $_POST['reps'];
    $username = $_SESSION['username']; // Use the username from the session

    // Prepare the INSERT statement
    $stmt = $conn->prepare("INSERT INTO UserWorkouts (Username, ExerciseName, Weight, Reps) VALUES (?, ?, ?, ?)");
    
    // Bind the parameters to the statement
    $stmt->bind_param("ssii", $username, $exerciseName, $weight, $reps);

    // Execute the statement and check if successful
    if ($stmt->execute()) {
        // If successful, set a success message or redirect
        $_SESSION['message'] = 'Workout logged successfully!';
        header('Location: log_workout.php'); // Redirect to the same page to show the message
        exit;
    } else {
        // If not successful, set an error message
        $_SESSION['error_message'] = 'Error logging workout: ' . $stmt->error;
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Log Workout</title>
    <link href="style.css" rel="stylesheet">
</head>
<body>
    <div class="container">
        <h1>Log Your Workout</h1>
        <form method="post" action="">
            <div class="form-group">
                <label for="exercise">Select Exercise:</label>
                <select name="exercise" id="exercise">
                    <?php foreach ($exercises as $exercise): ?>
                        <option value="<?php echo htmlspecialchars($exercise); ?>">
                            <?php echo htmlspecialchars($exercise); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="weight">Weight (lbs):</label>
                <input type="number" name="weight" id="weight" required>
            </div>
            <div class="form-group">
                <label for="reps">Reps:</label>
                <input type="number" name="reps" id="reps" required>
            </div>
            <button type="submit" class="btn">Log Exercise</button>
        </form>
        <a href="user.php" class="btn">Back to User Page</a>
        <a href="past_log.php" class="btn">View Past Logs</a>

    </div>
</body>
</html>




