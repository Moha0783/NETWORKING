'mubarak mohamoud'

import socket
import random
import time

# Server setup
server_port = 12000
server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
server_socket.bind(('', server_port))
print("Ready to receive pings")

while True:
    # Receive message and client address
    message, client_address = server_socket.recvfrom(1024)

    # Simulate random packet loss (drop up to 5 packets out of every 10)
    if random.random() < 0.5:
        print("Packet dropped")
        continue

    # Simulate random delay between 100ms and 500ms
    delay = random.uniform(0.1, 0.5)
    time.sleep(delay)

    # Respond to the client
    server_socket.sendto(message, client_address)
    print(f"Responded to {client_address} with delay {delay:.3f}s")
