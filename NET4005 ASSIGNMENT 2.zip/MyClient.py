'mubarak mohamoud'

import socket
import time
import random

# Client setup
server_name = 'localhost'
server_port = 12000
client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
client_socket.settimeout(2)  # 2 seconds timeout for response

# Ping statistics
num_pings = 10
rtts = []
lost_packets = 0

for i in range(1, num_pings + 1):
    send_time = time.time()  # Record send time
    message = f"Ping {i} {send_time}".encode()  # Create ping message

    try:
        # Send the ping message
        client_socket.sendto(message, (server_name, server_port))

        # Wait for the response
        response, server_address = client_socket.recvfrom(1024)

        # Record receive time and calculate RTT
        receive_time = time.time()
        rtt = receive_time - send_time
        rtts.append(rtt)

        print(f"Ping {i}: RTT = {rtt:.3f} seconds")

    except socket.timeout:
        # If timeout, increment lost packets count
        lost_packets += 1
        print(f"Ping {i}: Request timed out")

# After all pings, calculate statistics
if rtts:
    min_rtt = min(rtts)
    max_rtt = max(rtts)
    avg_rtt = sum(rtts) / len(rtts)
else:
    min_rtt = max_rtt = avg_rtt = 0

# Packet loss rate
packet_loss_rate = (lost_packets / num_pings) * 100

print("\n--- Ping statistics ---")
print(f"Minimum RTT: {min_rtt:.3f} seconds")
print(f"Maximum RTT: {max_rtt:.3f} seconds")
print(f"Average RTT: {avg_rtt:.3f} seconds")
print(f"Packet Loss Rate: {packet_loss_rate:.1f}%")

# Close the socket
client_socket.close()
